﻿import { useMemo, useRef } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { Float, Line, OrbitControls } from "@react-three/drei"
import * as THREE from "three"

type Node = { position: [number, number, number]; color: string }

function useNodes(count: number): Node[] {
  return useMemo(() => {
    const palette = ["#3B82F6", "#22D3EE", "#8B5CF6", "#60A5FA"]
    const nodes: Node[] = []
    for (let i = 0; i < count; i++) {
      const r = 2.2 + Math.random() * 1.4
      const theta = Math.random() * Math.PI * 2
      const phi = Math.acos(2 * Math.random() - 1)
      nodes.push({
        position: [
          r * Math.sin(phi) * Math.cos(theta),
          r * Math.cos(phi),
          r * Math.sin(phi) * Math.sin(theta),
        ],
        color: palette[i % palette.length],
      })
    }
    return nodes
  }, [count])
}

function Network({ count = 28 }: { count?: number }) {
  const group = useRef<THREE.Group>(null)
  const nodes = useNodes(count)

  const edges = useMemo(() => {
    const pairs: Array<[[number, number, number], [number, number, number]]> = []
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const a = new THREE.Vector3(...nodes[i].position)
        const b = new THREE.Vector3(...nodes[j].position)
        if (a.distanceTo(b) < 2.4) pairs.push([nodes[i].position, nodes[j].position])
      }
    }
    return pairs.slice(0, 90)
  }, [nodes])

  useFrame((state, delta) => {
    if (!group.current) return
    group.current.rotation.y += delta * 0.08
    group.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.15) * 0.15
  })

  return (
    <group ref={group}>
      {nodes.map((n, i) => (
        <Float key={i} speed={1.2} floatIntensity={0.4} rotationIntensity={0.2}>
          <mesh position={n.position}>
            <sphereGeometry args={[0.06, 16, 16]} />
            <meshStandardMaterial
              color={n.color}
              emissive={n.color}
              emissiveIntensity={1.4}
            />
          </mesh>
        </Float>
      ))}
      {edges.map((e, i) => (
        <Line
          key={i}
          points={[e[0], e[1]]}
          color="#3B82F6"
          lineWidth={0.6}
          transparent
          opacity={0.28}
        />
      ))}
    </group>
  )
}

export function DataNetwork() {
  return (
    <Canvas
      dpr={[1, 2]}
      camera={{ position: [0, 0, 7], fov: 50 }}
      gl={{ antialias: true, alpha: true }}
    >
      <ambientLight intensity={0.6} />
      <pointLight position={[5, 5, 5]} intensity={1.4} color="#60A5FA" />
      <pointLight position={[-5, -3, -5]} intensity={0.9} color="#8B5CF6" />
      <Network />
      <OrbitControls
        enableZoom={false}
        enablePan={false}
        autoRotate
        autoRotateSpeed={0.5}
        minPolarAngle={Math.PI / 3}
        maxPolarAngle={(2 * Math.PI) / 3}
      />
    </Canvas>
  )
}
