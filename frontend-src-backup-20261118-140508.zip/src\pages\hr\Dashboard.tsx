﻿import { useQuery } from "@tanstack/react-query"
import { getOverview, type ProficiencyBand } from "@/api/analytics"

const BANDS: ProficiencyBand[] = ["BEGINNER", "INTERMEDIATE", "ADVANCED", "EXPERT"]

function StatCard({ label, value }: { label: string; value: number | string }) {
  return (
    <div className="bg-white rounded-lg shadow-sm p-5 border border-slate-200">
      <div className="text-xs uppercase tracking-wide text-slate-500">{label}</div>
      <div className="text-3xl font-semibold mt-1">{value}</div>
    </div>
  )
}

export function Dashboard() {
  const { data, isLoading, error } = useQuery({ queryKey: ["analytics", "overview"], queryFn: getOverview })

  if (isLoading) return <p className="text-slate-500">Loading dashboard…</p>
  if (error || !data) return <p className="text-red-600">Failed to load dashboard.</p>

  const totalBand = Object.values(data.proficiency_by_band).reduce((a, n) => a + n, 0) || 1

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-2xl font-semibold">Dashboard</h1>
        <p className="text-slate-500 text-sm">Workforce snapshot across the organization.</p>
      </header>

      <section className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Employees" value={data.headcount} />
        <StatCard label="Departments" value={data.department_count} />
        <StatCard label="Projects" value={data.project_count} />
        <StatCard label="Active projects" value={data.active_project_count} />
      </section>

      <section className="grid md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-5">
          <h2 className="font-medium mb-3">Proficiency distribution</h2>
          <ul className="space-y-2">
            {BANDS.map((b) => {
              const n = data.proficiency_by_band[b] ?? 0
              const pct = Math.round((n / totalBand) * 100)
              return (
                <li key={b}>
                  <div className="flex justify-between text-sm mb-1">
                    <span>{b}</span>
                    <span className="text-slate-500">{n} ({pct}%)</span>
                  </div>
                  <div className="h-2 bg-slate-100 rounded">
                    <div className="h-2 bg-slate-700 rounded" style={{ width: `${pct}%` }} />
                  </div>
                </li>
              )
            })}
          </ul>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-5">
          <h2 className="font-medium mb-3">Top skills</h2>
          <table className="w-full text-sm">
            <thead className="text-slate-500 text-left">
              <tr>
                <th className="pb-2">Skill</th>
                <th className="pb-2 text-right">Employees</th>
              </tr>
            </thead>
            <tbody>
              {data.top_skills.map((s) => (
                <tr key={s.skill_id} className="border-t border-slate-100">
                  <td className="py-2">{s.skill_name}</td>
                  <td className="py-2 text-right">{s.total}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="grid md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-5">
          <h2 className="font-medium mb-3">Top gaps across projects</h2>
          {data.top_gaps.length === 0 ? (
            <p className="text-sm text-slate-500">No mandatory gaps — nice.</p>
          ) : (
            <ul className="space-y-2 text-sm">
              {data.top_gaps.map((g) => (
                <li key={g.skill_id} className="flex justify-between border-b border-slate-100 pb-2 last:border-0">
                  <span>{g.skill_name}</span>
                  <span className="text-slate-500">{g.gap_count} gap(s)</span>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-5">
          <h2 className="font-medium mb-3">Departments</h2>
          <table className="w-full text-sm">
            <thead className="text-slate-500 text-left">
              <tr>
                <th className="pb-2">Department</th>
                <th className="pb-2 text-right">Headcount</th>
                <th className="pb-2 text-right">Avg exp (yrs)</th>
              </tr>
            </thead>
            <tbody>
              {data.departments.map((d) => (
                <tr key={d.department_id} className="border-t border-slate-100">
                  <td className="py-2">{d.department_name}</td>
                  <td className="py-2 text-right">{d.headcount}</td>
                  <td className="py-2 text-right">{d.avg_experience_years}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  )
}
