﻿import { type FormEvent, useState } from "react"
import { Link, useNavigate } from "react-router-dom"
import { useAuth } from "./AuthContext"


export function LoginPage() {
  const { login } = useAuth()
  const nav = useNavigate()
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    setBusy(true)
    setError(null)
    try {
      await login(username, password)
      nav("/", { replace: true })
    } catch {
      setError("Invalid username or password")
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-[#0B1220] text-slate-100">
      {/* Left: 3D + brand */}
      <div className="relative hidden lg:flex flex-col justify-between p-10 overflow-hidden">
        <div className="absolute inset-0">
          <div className="text-slate-600">3D loading…</div>
        </div>
        <div className="relative z-10">
          <div className="text-2xl font-semibold tracking-tight">
            <span className="text-cyan-400">W</span>CIP
          </div>
          <p className="mt-1 text-xs uppercase tracking-[0.3em] text-slate-400">
            Workforce Capacity Intelligence
          </p>
        </div>
        <div className="relative z-10 max-w-md">
          <h1 className="text-4xl font-semibold leading-tight">
            Know your workforce.
            <br />
            <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              Staff with confidence.
            </span>
          </h1>
          <p className="mt-4 text-slate-400 text-sm leading-relaxed">
            Match people to projects, spot skill gaps before they stall delivery,
            and turn workforce data into decisions — all in one place.
          </p>
          <div className="mt-8 flex gap-6 text-xs text-slate-400">
            <div><span className="text-cyan-400 text-lg font-semibold">34+</span><br />Employees tracked</div>
            <div><span className="text-cyan-400 text-lg font-semibold">7</span><br />Departments</div>
            <div><span className="text-cyan-400 text-lg font-semibold">7</span><br />Active projects</div>
          </div>
        </div>
      </div>

      {/* Right: form */}
      <div className="flex items-center justify-center p-6 bg-[#0E1628]">
        <form
          onSubmit={onSubmit}
          className="w-full max-w-sm space-y-6 bg-white/[0.03] border border-white/10 rounded-2xl p-8 backdrop-blur-xl shadow-2xl"
        >
          <div>
            <h2 className="text-2xl font-semibold">Welcome back</h2>
            <p className="text-sm text-slate-400 mt-1">Sign in to your workspace</p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs uppercase tracking-wider text-slate-400 mb-2">Username</label>
              <input
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 text-sm placeholder:text-slate-500 outline-none focus:border-cyan-400/60 focus:ring-2 focus:ring-cyan-400/20 transition"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="your-username"
                required
                autoFocus
              />
            </div>
            <div>
              <label className="block text-xs uppercase tracking-wider text-slate-400 mb-2">Password</label>
              <input
                type="password"
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 text-sm placeholder:text-slate-500 outline-none focus:border-cyan-400/60 focus:ring-2 focus:ring-cyan-400/20 transition"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
              />
            </div>
          </div>

          {error && (
            <div className="text-sm text-red-400 bg-red-400/10 border border-red-400/20 rounded-lg px-3 py-2">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={busy}
            className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 text-white py-2.5 rounded-lg font-medium text-sm hover:from-cyan-400 hover:to-blue-500 transition disabled:opacity-60 shadow-lg shadow-blue-600/20"
          >
            {busy ? "Signing in…" : "Sign in"}
          </button>

          <p className="text-xs text-center text-slate-400">
            Don't have an account?{" "}
            <Link to="/signup" className="text-cyan-400 hover:text-cyan-300">
              Request access
            </Link>
          </p>
        </form>
      </div>
    </div>
  )
}

