﻿import { createBrowserRouter, Navigate } from "react-router-dom"
import { RequireAuth } from "@/features/auth/RequireAuth"
import { LoginPage } from "@/features/auth/LoginPage"
import { SignupPage } from "@/features/auth/SignupPage"
import { AppShell } from "@/layouts/AppShell"
import { Dashboard } from "@/pages/hr/Dashboard"

const Placeholder = ({ name }: { name: string }) => (
  <div className="text-slate-400">"{name}" coming soon.</div>
)

export const router = createBrowserRouter([
  { path: "/login", element: <LoginPage /> },
  { path: "/signup", element: <SignupPage /> },
  {
    element: <RequireAuth />,
    children: [
      {
        element: <AppShell />,
        children: [
          { index: true, element: <Dashboard /> },
          { path: "employees", element: <Placeholder name="Employees" /> },
          { path: "skills", element: <Placeholder name="Skills" /> },
          { path: "projects", element: <Placeholder name="Projects" /> },
          { path: "analytics", element: <Placeholder name="Analytics" /> },
          { path: "notifications", element: <Placeholder name="Notifications" /> },
        ],
      },
    ],
  },
  { path: "*", element: <Navigate to="/login" replace /> },
])
