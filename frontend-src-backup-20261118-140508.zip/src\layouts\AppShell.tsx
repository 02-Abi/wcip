﻿import { NavLink, Outlet, useNavigate } from "react-router-dom"
import { useAuth } from "@/features/auth/AuthContext"

const nav = [
  { to: "/", label: "Dashboard", end: true },
  { to: "/employees", label: "Employees" },
  { to: "/skills", label: "Skills" },
  { to: "/projects", label: "Projects" },
  { to: "/analytics", label: "Analytics" },
  { to: "/notifications", label: "Notifications" },
]

export function AppShell() {
  const { logout } = useAuth()
  const nav2 = useNavigate()
  return (
    <div className="min-h-screen flex bg-slate-50">
      <aside className="w-56 bg-slate-900 text-slate-100 flex flex-col">
        <div className="px-4 py-5 text-lg font-semibold border-b border-slate-700">WCIP</div>
        <nav className="flex-1 py-3">
          {nav.map((n) => (
            <NavLink
              key={n.to}
              to={n.to}
              end={n.end}
              className={({ isActive }) =>
                `block px-4 py-2 text-sm ${isActive ? "bg-slate-800 text-white" : "text-slate-300 hover:bg-slate-800"}`
              }
            >
              {n.label}
            </NavLink>
          ))}
        </nav>
        <button
          onClick={() => {
            logout()
            nav2("/login")
          }}
          className="px-4 py-3 text-sm text-left text-slate-300 hover:bg-slate-800 border-t border-slate-700"
        >
          Sign out
        </button>
      </aside>
      <main className="flex-1 p-8 overflow-auto">
        <Outlet />
      </main>
    </div>
  )
}
