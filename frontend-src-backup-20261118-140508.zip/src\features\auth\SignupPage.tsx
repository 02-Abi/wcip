﻿import { type FormEvent, useMemo, useState } from "react"
import { Link, useNavigate } from "react-router-dom"
import { useAuth } from "./AuthContext"

const RULES = [
  { id: "len", label: "At least 8 characters", test: (v: string) => v.length >= 8 },
  { id: "num", label: "Contains a number", test: (v: string) => /\d/.test(v) },
  { id: "alpha", label: "Contains a letter", test: (v: string) => /[A-Za-z]/.test(v) },
  { id: "special", label: "Contains a symbol (!@#$…)", test: (v: string) => /[^A-Za-z0-9]/.test(v) },
]

export function SignupPage() {
  const { signup } = useAuth()
  const nav = useNavigate()
  const [username, setUsername] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [password2, setPassword2] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  const ruleResults = useMemo(() => RULES.map((r) => ({ ...r, ok: r.test(password) })), [password])
  const passwordsMatch = password.length > 0 && password === password2
  const canSubmit = username.trim().length > 0 && email.includes("@") && ruleResults.every((r) => r.ok) && passwordsMatch

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    if (!canSubmit) { setError("Please satisfy all requirements."); return }
    setBusy(true); setError(null)
    try {
      await signup({ username: username.trim(), email: email.trim(), password, password2 })
      nav("/", { replace: true })
    } catch (err: any) {
      const data = err?.response?.data
      if (data && typeof data === "object") {
        const first = Object.values(data)[0]
        setError(typeof first === "string" ? first : "Signup failed.")
      } else {
        setError("Signup failed. Please try again.")
      }
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-[#0B1220] text-slate-100">
      <div className="flex items-center justify-center p-6 bg-[#0E1628] order-2 lg:order-1">
        <form onSubmit={onSubmit} className="w-full max-w-sm space-y-5 bg-white/[0.03] border border-white/10 rounded-2xl p-8 backdrop-blur-xl shadow-2xl">
          <div>
            <h2 className="text-2xl font-semibold">Create your account</h2>
            <p className="text-sm text-slate-400 mt-1">Get started with WCIP</p>
          </div>
          <div>
            <label className="block text-xs uppercase tracking-wider text-slate-400 mb-2">Username</label>
            <input className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-cyan-400/60 focus:ring-2 focus:ring-cyan-400/20" value={username} onChange={(e) => setUsername(e.target.value)} required autoFocus />
          </div>
          <div>
            <label className="block text-xs uppercase tracking-wider text-slate-400 mb-2">Email</label>
            <input type="email" className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-cyan-400/60 focus:ring-2 focus:ring-cyan-400/20" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <div>
            <label className="block text-xs uppercase tracking-wider text-slate-400 mb-2">Password</label>
            <input type="password" className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-cyan-400/60 focus:ring-2 focus:ring-cyan-400/20" value={password} onChange={(e) => setPassword(e.target.value)} required />
            <ul className="mt-2 space-y-1">
              {ruleResults.map((r) => (
                <li key={r.id} className={`text-xs ${r.ok ? "text-emerald-400" : "text-slate-500"}`}>
                  {r.ok ? "✓" : "○"} {r.label}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <label className="block text-xs uppercase tracking-wider text-slate-400 mb-2">Confirm password</label>
            <input type="password" className={`w-full bg-white/5 border rounded-lg px-3 py-2.5 text-sm outline-none focus:ring-2 ${password2 && !passwordsMatch ? "border-red-400/60 focus:ring-red-400/20" : "border-white/10 focus:border-cyan-400/60 focus:ring-cyan-400/20"}`} value={password2} onChange={(e) => setPassword2(e.target.value)} required />
          </div>
          {error && <div className="text-sm text-red-400 bg-red-400/10 border border-red-400/20 rounded-lg px-3 py-2">{error}</div>}
          <button type="submit" disabled={busy || !canSubmit} className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 text-white py-2.5 rounded-lg font-medium text-sm hover:from-cyan-400 hover:to-blue-500 transition disabled:opacity-50 shadow-lg shadow-blue-600/20">
            {busy ? "Creating account…" : "Create account"}
          </button>
          <p className="text-xs text-center text-slate-400">
            Already have an account?{" "}
            <Link to="/login" className="text-cyan-400 hover:text-cyan-300">Sign in</Link>
          </p>
        </form>
      </div>
      <div className="hidden lg:flex flex-col items-center justify-center p-10 relative overflow-hidden order-1 lg:order-2">
        <div className="text-4xl font-semibold">
          <span className="text-cyan-400">W</span>CIP
        </div>
        <p className="mt-3 text-slate-400 text-sm max-w-xs text-center">
          Join your organization's workforce intelligence platform.
        </p>
      </div>
    </div>
  )
}
